# To Do
- Refactor and clean up the codes
- Use params wherever possible
- Use getvariable only in functions that need it
- Remove unnecessary _allDevices expansion in other scripts where its not used
- Add CBA Setting for GPS Tracker Object (single), GPS Detection Class, and other stuff
- Rework on all public/mission variables used (standardize it)



# List of all missionNamespace variables
- ROOT_CYBERWARFARE_GPS_TRACKER_DEVICE
- ROOT_CYBERWARFARE_GPS_TRACKER_INDEX